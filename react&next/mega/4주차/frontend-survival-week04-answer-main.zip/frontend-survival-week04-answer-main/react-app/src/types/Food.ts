interface Food {
  id: string;
  name: string;
  price: number;
}

export default Food;
