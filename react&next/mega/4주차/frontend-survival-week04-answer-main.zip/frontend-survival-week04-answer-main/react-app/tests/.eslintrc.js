module.exports = {
  extends: ['plugin:codeceptjs/recommended'],
};
