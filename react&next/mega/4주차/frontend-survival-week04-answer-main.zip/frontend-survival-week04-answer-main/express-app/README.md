# Express REST API 만들기

데브로드 프론트엔드 생존코스 4주차 과제 풀이

## 실행하기

```shell
npm install

npx nodemon app.ts
```
